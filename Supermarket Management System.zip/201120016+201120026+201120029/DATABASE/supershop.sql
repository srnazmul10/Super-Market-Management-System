-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2021 at 04:48 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supershop`
--

-- --------------------------------------------------------

--
-- Table structure for table `catagories`
--

CREATE TABLE `catagories` (
  `CATID` varchar(20) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `DESCRIPTION` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catagories`
--

INSERT INTO `catagories` (`CATID`, `NAME`, `DESCRIPTION`) VALUES
('01', 'FISH', '6 KG RHUI FISH'),
('', '', ''),
('02', 'MEAT', '6KGS OF MUTTON');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `PRODID` varchar(20) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `CATAGORY` varchar(15) NOT NULL,
  `QUANTITY` varchar(25) NOT NULL,
  `PRICE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`PRODID`, `NAME`, `CATAGORY`, `QUANTITY`, `PRICE`) VALUES
('01', 'milk', 'DAIRY', '1l', '75'),
('02', 'mutton', 'MEAT', '2kg', '1300'),
('03', 'PEANUT', 'BEVERAGE', '5 KG', '2500');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `SELLERID` varchar(20) NOT NULL,
  `NAME` varchar(40) NOT NULL,
  `PASSWORD` varchar(32) NOT NULL,
  `GENDER` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`SELLERID`, `NAME`, `PASSWORD`, `GENDER`) VALUES
('01', 'SUMAIYA BINTE SHAHID', '123456', 'FEMALE'),
('02', 'ARIFUL ISLAM', 'SHANTO86', 'FEMALE'),
('03', 'MD NAZMUL ISLAM', '143143', 'MALE');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
